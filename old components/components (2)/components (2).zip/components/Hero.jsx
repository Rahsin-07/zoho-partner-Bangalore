'use client'
import { useEffect, useRef, useState, useCallback } from 'react'
import MotionStyles from './MotionStyles'

// Section 1 — Hero. Persistent H1 partner line on every slide,
// with an auto-advancing slider of the 6 service intros below it.
const slides = [
  {
    tag: 'Zoho Consulting',
    h: 'Subscribed to Zoho but still not seeing business growth?',
    p: "The platform isn't the problem, the implementation is. As a Zoho Authorized Partner based in Bangalore, we help Bangalore businesses configure and scale Zoho the right way so every rupee you invest in your subscription delivers measurable returns.",
    cta: 'Connect with a Zoho Specialist',
    icon: 'bi-rocket-takeoff',
    color: '#2563eb',
  },
  {
    tag: 'Custom Zoho Solutions',
    h: 'Looking for a Zoho Solution Custom Specifically to Your Bangalore Business?',
    p: 'A standard Zoho setup was not built for the way your Bangalore business actually runs. As a certified Zoho customization partner in Bangalore, we create Zoho solutions that fit your exact process, from custom modules and automations to third party integrations. Everything is set up for your business, nothing is generic.',
    cta: 'Design Your Custom Solution',
    icon: 'bi-sliders',
    color: '#dc2626',
  },
  {
    tag: 'Zoho Migration & Integration',
    h: 'Planning a Zoho Migration or Integration for Your Business?',
    p: 'Switching from your current software to Zoho? Or need Zoho synced with your website, ERP, or external platforms? We manage end to end Zoho migration and integration for Bangalore businesses, ensuring full data integrity and uninterrupted operations.',
    cta: 'Begin Your Migration',
    icon: 'bi-arrow-left-right',
    color: '#f59e0b',
  },
  {
    tag: 'Dedicated Zoho Analytics Expert',
    h: "Can't get a clear picture of your business performance in one place?",
    p: 'Work with a dedicated Zoho Analytics expert in Bangalore to build custom dashboards and tailored reports for your business, giving you live visibility into performance, sharper insights, and the confidence to act faster.',
    cta: 'Build My Custom Dashboard',
    icon: 'bi-bar-chart-line',
    color: '#2563eb',
  },
  {
    tag: 'Zoho CRM Implementation',
    h: 'Want to see exactly how Zoho CRM can transform your Bangalore sales process?',
    p: 'Most Bangalore businesses use Zoho CRM only to store contacts. As a Zoho CRM partner in Bangalore, we build intelligent pipelines, lead scoring systems, and sales automation that actively drive conversions, not just store data.',
    cta: 'Schedule a Live Demo',
    icon: 'bi-people-fill',
    color: '#dc2626',
  },
  {
    tag: 'Dedicated Zoho Developer',
    h: 'Need a Dedicated Zoho Developer Focused Entirely on Your Business?',
    p: 'New Zoho requirements coming in every week? Rather than outsourcing each task separately, hire a dedicated Zoho developer in Bangalore who works exclusively for your business, on demand, consistent, and fully committed.',
    cta: 'Hire a Zoho Developer',
    icon: 'bi-code-square',
    color: '#f59e0b',
  },
]

const moduleChips = [
  { label: 'Zoho CRM',       icon: 'bi-people-fill',    x: '2%',  y: '15%', delay: 0,   color: '#2563eb' },
  { label: 'Zoho Books',     icon: 'bi-journal-text',   x: '88%', y: '13%', delay: 0.4, color: '#dc2626' },
  { label: 'Zoho Creator',   icon: 'bi-app-indicator',  x: '90%', y: '64%', delay: 0.2, color: '#2563eb' },
  { label: 'Zoho Analytics', icon: 'bi-bar-chart-line', x: '1%',  y: '60%', delay: 0.8, color: '#f59e0b' },
]

const AUTOPLAY_MS = 5500

export default function Hero() {
  const ref = useRef(null)
  const [active, setActive] = useState(0)
  const [paused, setPaused] = useState(false)

  // Reveal animations
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target) }
      })
    }, { threshold: 0.05 })
    ref.current?.querySelectorAll('.fade-up').forEach(el => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  // Auto-advance (pause on hover)
  useEffect(() => {
    if (paused) return
    const id = setInterval(() => setActive(a => (a + 1) % slides.length), AUTOPLAY_MS)
    return () => clearInterval(id)
  }, [paused, active])

  const go = useCallback((i) => setActive((i + slides.length) % slides.length), [])
  const current = slides[active]

  return (
    <section id="hero" ref={ref} style={{
      background: 'linear-gradient(160deg, #fafaf7 0%, #f0ece5 100%)',
      padding: '92px 0 84px', position: 'relative', overflow: 'hidden',
    }}>
      <MotionStyles />

      {/* Tri color gradient blobs */}
      <div aria-hidden style={{ position: 'absolute', width: 540, height: 540, top: -200, left: -140, background: 'radial-gradient(circle at center, rgba(37,99,235,0.22), transparent 60%)', animation: 'blob-drift 14s ease-in-out infinite', pointerEvents: 'none' }} />
      <div aria-hidden style={{ position: 'absolute', width: 580, height: 580, bottom: -240, right: -180, background: 'radial-gradient(circle at center, rgba(245,158,11,0.18), transparent 60%)', animation: 'blob-drift 18s ease-in-out infinite reverse', pointerEvents: 'none' }} />
      <div aria-hidden style={{ position: 'absolute', width: 420, height: 420, top: '30%', right: '20%', background: 'radial-gradient(circle at center, rgba(220,38,38,0.12), transparent 60%)', animation: 'blob-drift 22s ease-in-out infinite', pointerEvents: 'none' }} />
      <div aria-hidden style={{ position: 'absolute', inset: 0, opacity: 0.45 }} className="dot-grid" />

      {/* Floating chips (desktop) */}
      <div aria-hidden style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
        {moduleChips.map((c, i) => (
          <div key={c.label} className="d-none d-xl-inline-flex"
            style={{
              position: 'absolute', left: c.x, top: c.y,
              background: 'rgba(255,255,255,0.94)', backdropFilter: 'blur(8px)',
              border: '1px solid #e8e3dc', borderRadius: 999, padding: '7px 14px',
              fontSize: '0.78rem', fontFamily: 'Inter,sans-serif', fontWeight: 600,
              color: '#334155', boxShadow: '0 10px 28px rgba(11,18,32,0.08)',
              alignItems: 'center', gap: 8,
              animation: `float-y ${5 + (i % 3) * 1.2}s ease-in-out ${c.delay}s infinite`,
              whiteSpace: 'nowrap',
            }}>
            <i className={`bi ${c.icon}`} style={{ color: c.color, fontSize: '0.95rem' }} />
            {c.label}
          </div>
        ))}
      </div>

      <div className="container position-relative" style={{ zIndex: 2 }}>
        {/* PERSISTENT HEADLINE — shown on every slide */}
        <div className="text-center fade-up" style={{ maxWidth: 1000, margin: '0 auto 46px' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 22 }}>
            <div className="pill">
              <span className="pill-dot" />
              <span>Zoho Authorized Partner · Bangalore, India</span>
              <span style={{ width: 1, height: 14, background: '#e8e3dc' }} />
              <span style={{ color: '#2563eb', fontWeight: 700 }}>
                <i className="bi bi-patch-check-fill" /> Certified
              </span>
            </div>
          </div>

          <h1 style={{
            fontFamily: 'Inter,sans-serif',
            fontSize: 'clamp(2.3rem, 5.6vw, 4.15rem)',
            fontWeight: 800, color: '#0b1220',
            marginBottom: 18, letterSpacing: '-0.028em', lineHeight: 1.05,
          }}>
            <span className="grad-blue-red">Zoho Authorized Partner</span><br />
            in <span className="grad-red-yellow">Bangalore, India</span>
          </h1>

          <p style={{
            fontSize: '1.1rem', color: '#475569', maxWidth: 760,
            margin: '0 auto', lineHeight: 1.7, fontFamily: 'Inter,sans-serif',
          }}>
            ZoFlowX is your trusted Zoho Consulting Partner. We configure, customize, migrate and manage Zoho the right way for Bangalore businesses, so <strong style={{ color: '#0b1220' }}>every rupee of your subscription works for you.</strong>
          </p>
        </div>

        {/* AUTO-ADVANCING SLIDER */}
        <div className="fade-up"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          style={{ maxWidth: 1080, margin: '0 auto', position: 'relative' }}>

          <div style={{
            background: '#fff', border: '1px solid #e8e3dc', borderRadius: 26,
            overflow: 'hidden', boxShadow: '0 30px 80px rgba(11,18,32,0.10)',
            position: 'relative',
          }}>
            {/* top accent bar tied to active color */}
            <div aria-hidden style={{ height: 4, background: current.color, transition: 'background 0.6s ease' }} />

            {/* track */}
            <div className="zx-hero-track" style={{ transform: `translateX(-${active * 100}%)` }}>
              {slides.map((s) => (
                <div key={s.tag} className="zx-hero-slide">
                  <div className="row g-0 align-items-stretch">
                    {/* text */}
                    <div className="col-lg-7" style={{ padding: 'clamp(28px, 4vw, 46px)' }}>
                      <span style={{
                        display: 'inline-flex', alignItems: 'center', gap: 8,
                        background: `${s.color}15`, color: s.color,
                        fontSize: '0.68rem', fontWeight: 800, letterSpacing: 1.5,
                        textTransform: 'uppercase', padding: '6px 14px', borderRadius: 50,
                        marginBottom: 18, fontFamily: 'Inter,sans-serif',
                      }}>
                        <i className={`bi ${s.icon}`} /> {s.tag}
                      </span>

                      <h2 style={{
                        fontFamily: 'Inter,sans-serif',
                        fontSize: 'clamp(1.4rem, 2.7vw, 2.05rem)', fontWeight: 800,
                        color: '#0b1220', lineHeight: 1.22, letterSpacing: '-0.02em',
                        marginBottom: 16,
                      }}>{s.h}</h2>

                      <p style={{
                        fontSize: '1rem', color: '#475569', lineHeight: 1.72,
                        marginBottom: 26, fontFamily: 'Inter,sans-serif',
                      }}>{s.p}</p>

                      <a href="#contact" className="btn-gradient ahover"
                        style={{ padding: '0.9rem 1.9rem', fontSize: '0.95rem' }}>
                        {s.cta} <i className="bi bi-arrow-right" />
                      </a>
                    </div>

                    {/* visual */}
                    <div className="col-lg-5 d-none d-lg-flex" style={{
                      alignItems: 'center', justifyContent: 'center',
                      background: `linear-gradient(150deg, ${s.color}10, ${s.color}02)`,
                      borderLeft: '1px solid #f0ece6', position: 'relative', overflow: 'hidden',
                    }}>
                      <div aria-hidden style={{ position: 'absolute', inset: 0, opacity: 0.5 }} className="dot-grid" />
                      <div style={{
                        width: 150, height: 150, borderRadius: 36,
                        background: '#fff', border: `1px solid ${s.color}30`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: s.color, fontSize: '4rem',
                        boxShadow: `0 26px 60px ${s.color}26`, position: 'relative',
                        transition: 'all 0.6s ease',
                      }}>
                        <i className={`bi ${s.icon}`} />
                        <div aria-hidden style={{
                          position: 'absolute', top: -10, right: -10,
                          width: 40, height: 40, borderRadius: '50%', background: '#fff',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          boxShadow: '0 8px 20px rgba(11,18,32,0.14)',
                        }}>
                          <i className="bi bi-patch-check-fill" style={{ color: s.color, fontSize: '1.3rem' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* DOTS + controls */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, marginTop: 26 }}>
            <button onClick={() => go(active - 1)} aria-label="Previous"
              style={{
                width: 40, height: 40, borderRadius: '50%', flexShrink: 0,
                background: '#fff', border: '1px solid #e8e3dc', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#0b1220', transition: 'all 0.25s',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = current.color; e.currentTarget.style.color = current.color }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#e8e3dc'; e.currentTarget.style.color = '#0b1220' }}>
              <i className="bi bi-arrow-left" />
            </button>

            <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              {slides.map((s, i) => {
                const isActive = i === active
                return (
                  <button key={s.tag} onClick={() => go(i)} aria-label={`Slide ${i + 1}: ${s.tag}`}
                    style={{
                      height: 9, width: isActive ? 42 : 9, borderRadius: 50,
                      border: 'none', padding: 0, cursor: 'pointer',
                      background: isActive ? '#e8e3dc' : '#d9d3ca',
                      position: 'relative', overflow: 'hidden',
                      transition: 'width 0.4s cubic-bezier(.2,.7,.2,1), background 0.3s',
                    }}>
                    {isActive && (
                      <span aria-hidden
                        key={`${active}-${paused}`}
                        className={paused ? '' : 'zx-dot-progress'}
                        style={{
                          position: 'absolute', top: 0, left: 0, bottom: 0,
                          width: paused ? '100%' : 0, background: s.color, borderRadius: 50,
                          animationDuration: `${AUTOPLAY_MS}ms`,
                        }} />
                    )}
                  </button>
                )
              })}
            </div>

            <button onClick={() => go(active + 1)} aria-label="Next"
              style={{
                width: 40, height: 40, borderRadius: '50%', flexShrink: 0,
                background: '#fff', border: '1px solid #e8e3dc', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#0b1220', transition: 'all 0.25s',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = current.color; e.currentTarget.style.color = current.color }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#e8e3dc'; e.currentTarget.style.color = '#0b1220' }}>
              <i className="bi bi-arrow-right" />
            </button>
          </div>

          {/* Persistent secondary CTAs under slider */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 12, flexWrap: 'wrap', marginTop: 24 }}>
            <a href="#contact" className="btn-white-soft ahover" style={{ padding: '0.82rem 1.8rem', fontSize: '0.92rem' }}>
              Book Free 30 Min Audit <i className="bi bi-calendar-check" />
            </a>
            <a href="#services" className="btn-white-soft ahover" style={{ padding: '0.82rem 1.8rem', fontSize: '0.92rem' }}>
              Explore Zoho Services <i className="bi bi-grid-3x3-gap" />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
